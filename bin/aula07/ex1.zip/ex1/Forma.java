package aula07.ex1;

public abstract class Forma {
    public String color;
    public abstract double area();
    public abstract double perimetro();

    public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
    }


}
