package poo_ex;

import java.util.concurrent.atomic.AtomicInteger;

public class Person {
    private String nome;
    private int cc;
    private DateYMD dataNasc;
    
    public Person(String iNome, int iBI, DateYMD iDataNasc){
        this.nome = iNome;
        this.cc = iBI;
        this.dataNasc = iDataNasc;
    }

    public String getName(){
        return this.nome;
    }
    public int getCC(){
        return this.cc;
    }
    public DateYMD getDataNasc(){
        return this.dataNasc;
    }


    @Override
    public String toString() {
        return this.nome + "; CC: " + this.cc + "; Data de Nascimento: " + this.dataNasc;
    }
}

class Aluno extends Person {
    private DateYMD dataInsc;
    private static final AtomicInteger count = new AtomicInteger(100); 
    private int nMec;
    
    public Aluno(String iNome, int iBI, DateYMD iDataNasc, DateYMD iDataInsc){
        super(iNome, iBI, iDataNasc);
        this.dataInsc = iDataInsc;
        nMec = count.getAndIncrement();
    }
    public Aluno(String iNome, int iBI, DateYMD iDataNasc){
        super(iNome, iBI, iDataNasc);
        this.dataInsc = new DateYMD();
        nMec = count.getAndIncrement();
    }

    public int getNMec() {
        return nMec;
    }

    public DateYMD getDataInsc() {
        return dataInsc;
    }

    @Override
    public String toString() {
        return getName() + "; CC: " + getCC() + "; Data de Nascimento: " + getDataNasc();
    }
}

class Bolseiro extends Aluno {
    private int bolsa;

    public Bolseiro(String iNome, int iBI, DateYMD iDataNasc, int iBolsa){
        super(iNome, iBI, iDataNasc);
        this.bolsa = iBolsa;
    }

    public int getBolsa(){
        return this.bolsa;
    }
    public void setBolsa(int bolsa){
        this.bolsa = bolsa;
    }
    @Override
    public String toString() {
        return getName() + "; CC: " + getCC() + "; Data de Nascimento: " + getDataNasc() + "; Numero Mecanografico: " + getNMec() + "; Valor da bolsa: " + getBolsa();
    }
}