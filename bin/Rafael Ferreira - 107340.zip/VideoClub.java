package poo_ex;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class VideoClub {
    private ArrayList<String> filmes = new ArrayList<>();
    private HashMap<Person, ArrayList<String>> rentals = new HashMap<>();

    public VideoClub(ArrayList<String> iTitulo){
        this.filmes = iTitulo;
    }

    public VideoClub(String iCaminho) throws FileNotFoundException{
        updateMovies(iCaminho);
    }

    public void randomRental(Person iPessoa){
        int ri = (int) (Math.random()*filmes.size());
        if(!rentals.containsKey(iPessoa)){
            rentals.put(iPessoa, new ArrayList<>());
        }
        rentals.get(iPessoa).add(filmes.get(ri));
    }

    public void listRentals(){
        for (Person pessoa : rentals.keySet()) {
            System.out.println(pessoa.getName() + ": " + rentals.get(pessoa).toString());
        }

    }

    private void updateMovies(String iCaminho) throws FileNotFoundException{
        Scanner scan = new Scanner(new File(iCaminho));
        while(scan.hasNextLine()){
            filmes.add(scan.nextLine());
        }
        scan.close();
    }

    
}
