package poo_ex;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.lang.StringBuilder;


public abstract class Date implements Comparable<Date>{
    //Vars
    public int day, month, year;

    //Abstract
    public abstract int getDay();
    public abstract int getMonth();
    public abstract int getYear();

    //Non-Abstract
    public static int todayDay() {
        DateTimeFormatter nowDayString = DateTimeFormatter.ofPattern("dd");
        StringBuilder DayString = new StringBuilder();
        DayString.append(nowDayString.format(LocalDateTime.now()));
        String dayStr = DayString.toString();

        return Integer.parseInt(dayStr);
    }
    public static int todayMonth() {
        DateTimeFormatter nowMonthString = DateTimeFormatter.ofPattern("MM");
        StringBuilder MonthString = new StringBuilder();
        MonthString.append(nowMonthString.format(LocalDateTime.now()));
        String monthStr = MonthString.toString();

        return Integer.parseInt(monthStr);
    }
    public static int todayYear() {
        DateTimeFormatter nowYearString = DateTimeFormatter.ofPattern("yyyy");
        StringBuilder YearString = new StringBuilder();
        YearString.append(nowYearString.format(LocalDateTime.now()));
        String yearStr = YearString.toString();

        return Integer.parseInt(yearStr);
    }
    public static boolean leapYear(int year){
        return (year%4==0) ? true : false;
    }
    public static boolean validMonth(int month){
        return (month < 0 || month > 12) ? false : true ;
    }

    public static int monthDays(int month, int year){
        int days = 0;

        switch(month){
            case 4:
            case 6:
            case 9:
            case 11: days = 30; break;
            case 2: days = (leapYear(year)) ? 29 : 28; break;
            default: days = 31;
        }

        return days;
    }

    public static boolean valid(int day, int month, int year){
        if (validMonth(month)){
            if (day > 0 && day < monthDays(month, year)+1){
                return true;
            }
        }
        return false;
    }
    
    @Override
    public int compareTo(Date date){
		if(this.year < date.year) return -1;
        if(this.year > date.year) return 1;
        if(this.month < date.month) return -1;
        if(this.month > date.month) return 1;
        if(this.day < date.day) return -1;
        if(this.day > date.day) return 1;
        return 0;
    }

}

class DateYMD extends Date{

    public DateYMD(int day, int month, int year){
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public DateYMD(){
        this.day = todayDay();
        this.month = todayMonth();
        this.year = todayYear();
    }

    public void set(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;     
    }

    public int getDay() {
        return this.day;
    }

    public int getMonth() {
        return this.month;
    }

    public int getYear() {
        return this.year;
    }

    public void increment() {
        if(valid(day+1, month, year)){
            set(day+1, month, year);
        }
        else if(valid(1, month+1, year)){
            set(1, month+1, year);
        }
        else{
            set(1, 1, year+1);
        }
    }

    public void decrement() {
        if(valid(day-1, month, year)){
            set(day-1, month, year);
        }
        else if(valid(monthDays(month-1, year), month-1, year)){
            set(monthDays(month-1, year), month-1, year);
        }
        else{
            set(31, 12, year-1);
        }
    }

    

    @Override
    public String toString() {
        return this.year + "-" + this.month + "-" + this.day;
    }
}

class DateND extends Date{
    public int distance;
    public static int DEFAULT_YEAR = 2000;
    public static int DEFAULT_MONTH = 1;
    public static int DEFAULT_DAY = 1;
    public int years, months, days, allDays;

    public DateND(int day, int month, int year){
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public DateND(){
        this.day = todayDay();
        this.month = todayMonth();
        this.year = todayYear();
    }

    public int getYear() {
        return this.year;
    }
    public int getMonth() {
        return this.month;
    }
    public int getDay() {
        return this.day;
    }
    
    public void set(int day, int month, int year) {
        if (valid(day, month, year)){
            this.day = day;
            this.month = month;
            this.year = year;  
        }
    }

    public void setToToday() {
        this.day = todayDay();
        this.month = todayMonth();
        this.year = todayYear();
    }

    public void distanceToDefault(){
        years = this.year - DEFAULT_YEAR;
        months = this.month - DEFAULT_MONTH;
        days = this.days - DEFAULT_DAY;

        if (years < 0){
            years = -years-1;
            months = 11 - months;
            days = 31- days;

            switch(months){
                case 11: days = 28;
                case 10: days = 31;
                case 9: days += 30;
                case 8: days += 31;
                case 7: days += 31;
                case 6: days += 30;
                case 5: days += 31;
                case 4: days += 30;
                case 3: days += 31;
                case 2: days += 30;
                case 1: days += 31;
                case 0: days += 0; break; 
            }
            days += years*365 + ((int)(years/4));
        }
        else{
            switch(months){
                case 11: days = 30;
                case 10: days = 31;
                case 9: days += 30;
                case 8: days += 31;
                case 7: days += 31;
                case 6: days += 30;
                case 5: days += 31;
                case 4: days += 30;
                case 3: days += 31;
                case 2: days += 28;
                case 1: days += 31;
                case 0: days += 0; break; 
            }
            days += years*365 + ((int)(years/4)) + 1;
        }
                
        System.out.println("Days: " + days);
    }

    @Override
    public String toString() {
        return "Distance to 1/1/2000 is " + this.distance + " days.";
    }

}


